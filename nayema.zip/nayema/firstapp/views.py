from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def app(request):
    return render(request, 'welcome.html')
def My_Name(request):
    return render(request, 'myname.html')
def My_Hobby(request):
    return render(request, 'hobby.html')

