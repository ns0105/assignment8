from django.urls import path
from . import views

urlpatterns = [
    path('', views.app),
    path('mn/', views.My_Name),
    path('mh/', views.My_Hobby),

]
